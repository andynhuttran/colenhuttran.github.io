package com.wap.lab12.repository;

import com.wap.lab12.object.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class ProductRepository {
    private static List<Product> list = new ArrayList<>();

    static {
        for (char c = 'A'; c <= 'Z'; ++c){
            Product product = new Product();
            product.setId(c - 'A' + 1);
            product.setName("Product " + c);
            product.setPrice(Math.round(new Random().nextFloat()*100.0)/100.0f);
            list.add(product);
        }
    }

    public static List<Product> getProducts(){
        return list;
    }

    public static Optional<Product> getProductById(int id){
       /* return list.stream().filter((p) -> p.getId() == id)
                .findFirst();*/

        for (Product product : list){
            if (product.getId() == id){
                return Optional.of(product);
            }
        }
        return Optional.ofNullable(null);
    }



}
