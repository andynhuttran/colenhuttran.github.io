package com.wap.lab12.object;

import java.util.HashMap;
import java.util.Map;

public class Cart {
    private Map<Product, Integer> map = new HashMap<>();

    public void addProduct(Product product){
        map.put(product, map.getOrDefault(product, 0) + 1);
    }

    public void updateProduct(Product product, int quantity){
        if (map.containsKey(product)) {
            map.replace(product, quantity);
        }
        else {
            map.put(product, quantity);
        }
    }

    public void removeProduct(Product product){
        if (map.containsKey(product)) {
            map.remove(product);
        }
    }

    public Map<Product, Integer> getProducts(){
        return map;
    }


    public int getQuantity(){
        return this.map.size();
    }


}
