package com.wap.lab12.controller;

import com.wap.lab12.object.Cart;
import com.wap.lab12.object.Product;
import com.wap.lab12.repository.ProductRepository;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Optional;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Integer id = Integer.valueOf(req.getParameter("id"));
        HttpSession httpSession = req.getSession(true);

        Cart cart = new Cart();
        if (httpSession.getAttribute("cart") != null){
            cart = (Cart)httpSession.getAttribute("cart");
        }

        Optional<Product> product = ProductRepository.getProductById(id);
        if (product.isPresent()) {
            cart.addProduct(product.get());
        }

        httpSession.setAttribute("cart", cart);
        Cookie cookie = new Cookie("cart", String.valueOf(cart.getQuantity()));
    }
}
