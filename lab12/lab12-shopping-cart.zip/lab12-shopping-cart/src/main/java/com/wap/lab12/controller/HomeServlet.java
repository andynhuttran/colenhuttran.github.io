package com.wap.lab12.controller;

import com.wap.lab12.object.Cart;
import com.wap.lab12.object.Product;
import com.wap.lab12.repository.ProductRepository;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        home(req, resp);
        req.getRequestDispatcher("/home.jsp").forward(req, resp);
    }

    private void home(HttpServletRequest req, HttpServletResponse resp){
        Cart cart = new Cart();
        HttpSession httpSession = req.getSession();
        if (httpSession != null){
            cart = (Cart)httpSession.getAttribute("cart");
        }

        req.setAttribute("cart", cart);

        List<Product> products = ProductRepository.getProducts();
        req.setAttribute("products", products);
    }
}
