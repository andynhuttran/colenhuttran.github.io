let cart = new Map();

window.onload = function() {
    let buttons = document.querySelectorAll(".item > button");
    buttons.forEach(function(btn){
        btn.onclick = order;
    });
}


function order(){
    let id = this.getAttribute("pId");
    let name = this.getAttribute("pName");
    let price = this.getAttribute("pPrice");
    console.log(id);

    let found = 0;
    for (let product of cart.keys()) {
        if (product.id == id){
            cart.set(product, cart.get(product)+1);
            found++;
            break;
        }
    }
    if (found == 0) {
        cart.set(new Product(id, name, price), 1);
    }

    updateCart();
}

function updateCart(){
    console.log(cart);

    let selected = document.getElementById("selected-product");
    selected.innerHTML = "";

    let total = 0;

    for (let product of cart.keys()) {
        let element = document.createElement("p");
        element.innerHTML = "Name: " + product.name;
        element.innerHTML += " - $" + product.price;

        element.innerHTML += "x" + cart.get(product);
        let amount = cart.get(product)*product.price;
        amount = Math.round(amount * 100) / 100;

        element.innerHTML += " = " + amount;

        total += amount;
        selected.append(element);
        selected.append(document.createElement("hr"));
    }

    let elementTotal = document.createElement("p");

    total = Math.round(total * 100) / 100;
    elementTotal.innerHTML = "Total: $" + total;
    selected.append(elementTotal);
}

function Product(id, name, price){
    this.id = id;
    this.name = name;
    this.price = price;
}
