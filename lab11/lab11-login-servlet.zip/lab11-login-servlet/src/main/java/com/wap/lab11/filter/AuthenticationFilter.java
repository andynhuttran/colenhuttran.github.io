package com.wap.lab11.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(
        filterName = "authenticationFilter",
        servletNames = {"profile-servlet", "home-servlet"}
)
public class AuthenticationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        HttpServletRequest httpServletRequest = (HttpServletRequest)request;

        HttpSession httpSession = httpServletRequest.getSession(false);
        if (httpSession != null){ //login already
            chain.doFilter(request, response);
        }
        else { //need to login
            ((HttpServletResponse)response).sendRedirect("/lab11");
        }

    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void destroy() {

    }
}
