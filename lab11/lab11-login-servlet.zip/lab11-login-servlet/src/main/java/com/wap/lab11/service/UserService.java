package com.wap.lab11.service;

import com.wap.lab11.object.User;

import java.util.HashMap;
import java.util.Map;

public class UserService {

    private static Map<String, User> users = new HashMap<>();

    static {
        //create dummy user base on alphabet
        for (char c = 'a'; c <= 'z'; ++c) {
            String str = String.valueOf(c);
            users.put(str, new User(str, str));
        }
    }

    public static User getUserByUsername(String username){
        if (users.containsKey(username)){
            return users.get(username);
        }
        return null;
    }


}
