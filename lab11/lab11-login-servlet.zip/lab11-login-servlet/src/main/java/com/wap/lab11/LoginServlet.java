package com.wap.lab11;

import com.wap.lab11.object.User;
import com.wap.lab11.service.UserService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.stream.Stream;

@WebServlet("/")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        HttpSession httpSession = req.getSession(false);
        if (httpSession != null){
            resp.sendRedirect("/lab11/profile");
            return;
        }

        PrintWriter writer = resp.getWriter();

        writer.print("<html>");
        writer.print("<head><title>Login</title></head>");
        writer.print("<body>");

            String err = req.getParameter("err");
            if (err != null && err.length() > 0){
                writer.print("<p style='color: red;'>");
                writer.print(err);
                writer.print("</p>");
            }

            writer.print("<form method='POST'>");

            String uid = null;
            String pwd = null;
            String rem = null;

            for (Cookie cookie : req.getCookies()){
                String cookieName = cookie.getName();
                if (cookieName.equals("uid")) {
                    uid = cookie.getValue();
                    System.out.println("uid: " + uid);
                }
                else if (cookieName.equals("pwd")) {
                    pwd = cookie.getValue();
                    System.out.println("pwd: " + pwd);
                }
                else if (cookieName.equals("rem")) {
                    rem = cookie.getValue();
                    System.out.println("rem: " + rem);
                }
            }

                if (uid == null) {
                    writer.print("<p>Name: <input name='uid' /></p>");
                }
                else {
                    writer.print(String.format("<p>Name: <input name='uid' value='%s' /></p>", uid));
                }

                if (pwd == null) {
                    writer.print("<p>Password: <input type='password' name='pwd' /></p>");
                }
                else {
                    writer.print(String.format("<p>Password: <input type='password' value='%s' name='pwd' /></p>", pwd));
                }

                if (rem == null) {
                    writer.print("<p><label><input type='checkbox' name='rem' />Remmeber</label></p>");
                }
                else {
                    writer.print("<p><label><input type='checkbox' checked name='rem' />Remmeber</label></p>");
                }

                writer.print("<p><input type='submit' value='Login' /></p>");

            writer.print("</form>");
        writer.print("</body>");
        writer.print("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = this.authenticate(req, resp);
        if (user == null) return;

        createSession(req, resp, user);
        handleCookie(req, resp, user);

        resp.sendRedirect("/lab11/profile");
    }

    private void handleCookie(HttpServletRequest req, HttpServletResponse resp, User user){
        boolean remember = "on".equalsIgnoreCase(req.getParameter("rem"));

        if (remember){
            System.out.println("Create Cookie");
            Cookie cookieUsername = new Cookie("uid", user.getUsername());
            Cookie cookiePassword = new Cookie("pwd", user.getPassword());
            Cookie cookieRem = new Cookie("rem", "on");

            cookieUsername.setMaxAge(60*60*24*30);
            cookiePassword.setMaxAge(60*60*24*30);
            cookieRem.setMaxAge(60*60*24*30);

            resp.addCookie(cookieUsername);
            resp.addCookie(cookiePassword);
            resp.addCookie(cookieRem);
        }
        else {
            System.out.println("Delete Cookie");
            Cookie cookieUsername = new Cookie("uid", "");
            Cookie cookiePassword = new Cookie("pwd", "");
            Cookie cookieRem = new Cookie("rem", "");

            cookieUsername.setMaxAge(0);
            cookiePassword.setMaxAge(0);
            cookieRem.setMaxAge(0);

            resp.addCookie(cookieUsername);
            resp.addCookie(cookiePassword);
            resp.addCookie(cookieRem);
        }
    }

    private void createSession(HttpServletRequest req, HttpServletResponse resp, User user){
        HttpSession httpSession = req.getSession();
        httpSession.setAttribute("user-info", user);
    }

    private User authenticate(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String uid = req.getParameter("uid");
        String password = req.getParameter("pwd");

        User user = UserService.getUserByUsername(uid);
        if (user == null || user.getPassword().equals(password) == false){
            resp.sendRedirect("/lab11?err=login info is invalid");
            return null;
        }

        return user;
    }
}
