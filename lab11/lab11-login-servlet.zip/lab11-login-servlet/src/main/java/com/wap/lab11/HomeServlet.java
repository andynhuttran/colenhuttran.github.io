package com.wap.lab11;

import com.wap.lab11.object.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "home-servlet", urlPatterns = {"/home"})
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession httpSession = req.getSession(false);
        User user = (User)httpSession.getAttribute("user-info");

        PrintWriter writer = resp.getWriter();

        writer.print("<html>");
        writer.print("<head><title>Home Page</title></head>");
        writer.print("<body>");

        writer.print("<form method='POST'>");

        writer.print(String.format("<p>Hello %s!</p>", user.getUsername()));
        writer.print(String.format("<p>This is your home page</p>"));

        writer.print(String.format("<p><a href='/lab11/profile'>profile</a></p>"));


        writer.print("<p><input type='submit' value='Logout' /></p>");

        writer.print("</form>");
        writer.print("</body>");
        writer.print("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession httpSession = req.getSession(false);
        if (httpSession != null){
            httpSession.invalidate();
        }

        resp.sendRedirect("/lab11");
    }
}
