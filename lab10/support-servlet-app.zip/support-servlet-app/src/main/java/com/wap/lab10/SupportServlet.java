package com.wap.lab10;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/support")
public class SupportServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter writer = resp.getWriter();

        writer.print("<html>");
        writer.print("<head></head>");

        writer.print("<body>");

            writer.print("<form action='support' method='POST'>");

            writer.print("Name: <input name='name' /><br/>");
            writer.print("Email: <input name='email' /><br/>");
            writer.print("Problem: <input name='problem' /><br/>");
            writer.print("Problem Description: <textarea name='problemDetail'></textarea><br/>");
            writer.print("<input type='submit' value='help' />");

            writer.print("</form>");

        writer.print("</body>");
        writer.print("</html>");

    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String email = req.getParameter("email");

        String supportEmail = this.getServletContext().getInitParameter("support-email");

        String format = "Thank you! %s for contacting us. We should receive reply from us with in 24 hrs in\n" +
                "your email address %s. Let us know in our support email %s if\n" +
                "you don’t receive reply within 24 hrs. Please be sure to attach your reference\n" +
                "%d in your email.";

        PrintWriter writer = resp.getWriter();
        String msg = String.format(format, name, email, supportEmail, System.currentTimeMillis());
        writer.print(msg);
    }
}
